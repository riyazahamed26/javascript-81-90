# Pixel-Art-Maker-Website
Description<br/>
A website for drawing pixel art on an adjustable size canvas, with the ability to extract drawings into PNG images too using only html, css and javascript.<br/>
To run the project just open index.html to your browser.<br/>
#Screenshot of the project:<br/>
![Screenshot of the website](/Pixel-Art-Maker/dallasGeorge/pixelArtMaker.png?raw=true "Pixel Art Maker")
