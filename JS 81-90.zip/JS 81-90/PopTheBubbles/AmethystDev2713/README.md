# Pop The Bubbles!

A fun little JavaScript demo. 5 bubbles will spawn every second, and you can click on one to pop it. Can you pop them all?

![Screenshot](https://raw.githubusercontent.com/AmethystDev2713/javascript-mini-projects/PopTheBubbles-AmethystDev2713-branch/PopTheBubbles/AmethystDev2713/image.png)
