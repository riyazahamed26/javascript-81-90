## This is how the project looks like 
![quiz-app](pic1.png)
![quiz-app](pic2.png)